#ifdef __GNUC__
# define AMACH amach_
# define DMACH dmach_
# define MACHINE_DUMP machine_dump__
#else
# define AMACH amach_
# define DMACH dmach_
# define MACHINE_DUMP machine_dump_
#endif

/* machine dependent part of IMSL library */
float AMACH (int *);
double DMACH (int *);

#ifndef __GNUC__
/* IEEE-754 single precision values */
float r_infinity_ ();
float r_quiet_nan_ ();
float r_signaling_nan_ ();
float r_min_normal_ ();
float r_min_subnormal_ ();
float r_max_normal_ ();
float r_max_subnormal_ ();
#endif

#ifndef __GNUC__
/* IEEE-754 double precision values */
double d_infinity_ ();
double d_quiet_nan_ ();
double d_signaling_nan_ ();
double d_min_normal_ ();
double d_min_subnormal_ ();
double d_max_normal_ ();
double d_max_subnormal_ ();
#endif

void float_dump (float value, char *label)
{
    union {
	float f;
	unsigned int i;
	unsigned short int s[2];
	unsigned char c[4];
    } z;

    z.f = value;
#ifdef __i386__
    printf ("%s%.20g (%02x %02x %02x %02x)\n",
	    label, z.f, z.c[3], z.c[2], z.c[1], z.c[0]);
#else
    printf ("%s%.20g (%02x %02x %02x %02x)\n",
	    label, z.f, z.c[0], z.c[1], z.c[2], z.c[3]);
#endif

}

void double_dump (double value, char *label)
{
    union {
	double d;
	unsigned int i[2];
	unsigned short int s[4];
	unsigned char c[8];
    } z;

    z.d = value;
#ifdef __i386__
    printf ("%s%.25g (%02x %02x %02x %02x %02x %02x %02x %02x)\n",
	    label, z.d, z.c[7], z.c[6], z.c[5], z.c[4], z.c[3], z.c[2], z.c[1], z.c[0]);
#else
    printf ("%s%.25g (%02x %02x %02x %02x %02x %02x %02x %02x)\n",
	    label, z.d, z.c[0], z.c[1], z.c[2], z.c[3], z.c[4], z.c[5], z.c[6], z.c[7]);
#endif
}

void MACHINE_DUMP ()
{
    int i;
    char buff[32];

    printf ("\nSingle precision values from IMSL AMACH() function:\n");
    for (i=1; i<9; i++)
    {
	snprintf (buff, sizeof(buff)-1, " AMACH(%d) = ", i); buff[sizeof(buff)-1] = '\0';
	float_dump (AMACH (&i), buff);
    }

#if defined (__FLT_MAX__) || !defined (__GNUC__)
    printf ("\nSingle precision values from IEEE-754 standard:\n");
#endif
#if defined (__FLT_MAX__)
    float_dump (__FLT_MAX__, " max normal ");
    float_dump (__FLT_MIN__, " min normal ");
    float_dump (__FLT_DENORM_MIN__, " min subnormal ");
#elif !defined (__GNUC__)
    float_dump (r_max_normal_ (), " max normal ");
    float_dump (r_min_normal_ (), " min normal ");
    float_dump (r_max_subnormal_ (), " max subnormal ");
    float_dump (r_min_subnormal_ (), " min subnormal ");
    float_dump (r_quiet_nan_ (), " quiet ");
    float_dump (r_signaling_nan_ (), " signalig ");
    float_dump (r_infinity_ (), " ");
#endif

    printf ("\nDouble precision values from IMSL DMACH() function:\n");
    for (i=1; i<9; i++)
    {
	snprintf (buff, sizeof(buff)-1, " DMACH(%d) = ", i); buff[sizeof(buff)-1] = '\0';
	double_dump (DMACH (&i), buff);
    }

#if defined (__DBL_MAX__) || !defined (__GNUC__)
    printf ("\nDouble precision values from IEEE-754 standard:\n");
#endif
#if defined (__DBL_MAX__)
    double_dump (__DBL_MAX__, " max normal ");
    double_dump (__DBL_MIN__, " min normal ");
    double_dump (__DBL_DENORM_MIN__, " min subnormal ");
#elif !defined (__GNUC__)
    double_dump (d_max_normal_ (), " max normal ");
    double_dump (d_min_normal_ (), " min normal ");
    double_dump (d_max_subnormal_ (), " max subnormal ");
    double_dump (d_min_subnormal_ (), " min subnormal ");
    double_dump (d_quiet_nan_ (), " quiet ");
    double_dump (d_signaling_nan_ (), " signalig ");
    double_dump (d_infinity_ (), " ");
#endif

}
